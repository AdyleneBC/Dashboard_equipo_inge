#####################################################

#Importamos librerias
import streamlit as st
import plotly.express as px
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import numpy as np
import plotly.figure_factory as ff
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, accuracy_score, classification_report


######################################################

#Nombre en el navegador
st.set_page_config(page_title="DataAnalyzer", page_icon="🌎", layout="wide")
######################################################

#Definimos la instancia
@st.cache_resource
######################################################

#Creamos la función de carga de datos
def load_data():
    dfA = pd.read_csv("Albany.csv")
    dfV = pd.read_csv("Valencia.csv")
    dfB = pd.read_csv("Bangkook.csv")
    dfM = pd.read_csv("Mexico.csv")

    # Selecciono columnas relevantes
    selected_cols = [
        'host_id', 'host_identity_verified', 'neighbourhood', 'host_is_superhost',
        'room_type', 'accommodates', 'amenities', 'price', 'minimum_nights',
        'number_of_reviews', 'reviews_per_month', 'host_name',
        'availability_365', 'host_response_time', 'bathrooms_text', 'bathrooms',
        'bedrooms', 'beds', 'has_availability', 'instant_bookable', 'name'
    ]
    dfM= dfM[selected_cols]
    dfA = dfA[selected_cols]
    dfV = dfV[selected_cols]
    dfB = dfB[selected_cols]
############################################################################################################
############################################################################################################
##################################################ALBANY####################################################
    dfB['price'] = dfB['price'].replace('[\$,]', '', regex=True).astype(float).astype(int)
    # #Concierte a Dolares Valencia
    # conversion_rate = 1.08  # ejemplo: 1 euro = 1.08 dólares
    # dfV['price'] = dfV['price'] * conversion_rate
    # dfV = dfV[dfV['price'] <= 800]
    # #Dolares Mexico
    # tipo_cambio = 17.00
    # dfM['price'] = pd.to_numeric(dfM['price'], errors='coerce')
    # dfM['price'] = dfM['price'] / tipo_cambio

    # # Dólares Bangkook
    # cambio = 34.00
    # dfB['price'] = pd.to_numeric(dfB['price'], errors='coerce')
    # dfB['price'] = dfB['price'] / cambio

###################################################################################
    # Columnas numéricas
    numeric_df = dfA.select_dtypes(include=['float', 'int'])
    numeric_cols = numeric_df.columns

    # Columnas de texto/categóricas
    text_df = dfA.select_dtypes(include=['object'])
    text_cols = text_df.columns

    # Categorías únicas de 'room_type'
    unique_categories_room = dfA['room_type'].unique()
#########################################################################################
################################################
    # Columnas numéricas
    numeric_df_A = dfA.select_dtypes(include=['float', 'int'])
    numeric_cols_A = numeric_df_A.columns

    # Columnas de texto/categóricas
    text_df_A = dfA.select_dtypes(include=['object'])
    text_cols_A = text_df_A.columns

    # Categorías únicas de 'room_type'
    unique_categories_room_A = dfA['room_type'].unique()

#####################################################################################################################################
####################################################VALENCIA############################################################################
    # Columnas numéricas
    numeric_df_V = dfV.select_dtypes(include=['float', 'int'])
    numeric_cols_V = numeric_df_V.columns

    # Columnas de texto/categóricas
    text_df_V = dfV.select_dtypes(include=['object'])
    text_cols_V = text_df_V.columns

    # Categorías únicas de 'room_type'
    unique_categories_room_V = dfV['room_type'].unique()

#####################################################################################################################################
#####################################################BANGKOOK################################################################################
# Columnas numéricas
    numeric_df_B = dfB.select_dtypes(include=['float', 'int'])
    numeric_cols_B = numeric_df_B.columns

    # Columnas de texto/categóricas
    text_df_B = dfB.select_dtypes(include=['object'])
    text_cols_B = text_df_B.columns

    # Categorías únicas de 'room_type'
    unique_categories_room_B = dfB['room_type'].unique()

#####################################################################################################################################
#####################################################MÉXICO################################################################################
# Columnas numéricas
    numeric_df_M = dfM.select_dtypes(include=['float', 'int'])
    numeric_cols_M = numeric_df_M.columns

    # Columnas de texto/categóricas
    text_df_M = dfM.select_dtypes(include=['object'])
    text_cols_M = text_df_M.columns

    # Categorías únicas de 'room_type'
    unique_categories_room_M = dfM['room_type'].unique()


#####################################################################################################################################
#####################################################################################################################################
    return dfA, numeric_cols_A, text_cols_A, unique_categories_room_A, numeric_df_A, dfV, numeric_cols_V, text_cols_V, unique_categories_room_V, numeric_df_V, dfB, numeric_cols_B, text_cols_B, unique_categories_room_B, numeric_df_B, dfM, numeric_cols_M, text_cols_M, unique_categories_room_M, numeric_df_M, numeric_cols, text_cols, unique_categories_room, numeric_df

#Cargo los datos obtenidos de la función "load_data"
dfA, numeric_cols_A, text_cols_A, unique_categories_room_A, numeric_df_A, dfV, numeric_cols_V, text_cols_V, unique_categories_room_V, numeric_df_V, dfB, numeric_cols_B, text_cols_B, unique_categories_room_B, numeric_df_B, dfM, numeric_cols_M, text_cols_M, unique_categories_room_M, numeric_df_M, numeric_cols, text_cols, unique_categories_room, numeric_df = load_data()
#######################################################################################################

#####################################################################################################################################
#####################################################################################################################################
#************CREACIÓN DEL DASHBOARD***********CREACIÓN DEL DASHBOARD************CREACIÓN DEL DASHBOARD*****CREACIÓN DEL DASHBOARD

#LOGO DEL SIDEBAR
st.sidebar.image("logo_albany.png", caption="Dashboard")

# FONDO DEGRADADO BACKGROOUND
st.markdown("""
    <style>
    .stApp {
        background: linear-gradient(to bottom, 
             rgb(136, 14, 79),   /* rosa fuerte */
            rgb(91, 44, 111),    /* morado */
            rgb(20, 20, 20)       /* casi negro */
        );
        background-attachment: fixed;
        color: white;
    }

    h3 {
        color: #E63946;
        font-weight: bold;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
        padding-bottom: 0.5rem;
        border-bottom: 3px solid gray;
        margin-bottom: 1rem;
        text-align: center;
    }
    </style>
    """, unsafe_allow_html=True)

#CREAMOS LOS BOTONES DEL SIDEBAR
# Inicializar estado si no existe
if "submenu" not in st.session_state:
    st.session_state.submenu = "DataAnalyzer"  # por default

# Botones del submenú
if st.sidebar.button("DataAnalyzer", use_container_width=True):
    st.session_state.submenu = "DataAnalyzer"

if st.sidebar.button("Análisis Númerico y Categórico", use_container_width=True):
    st.session_state.submenu = "Análisis Númerico y Categórico"

if st.sidebar.button("Regresión", use_container_width=True):
    st.session_state.submenu = "Regresión"

if st.sidebar.button("Precios", use_container_width=True):
    st.session_state.submenu = "Precios"

#BOTÓN DE INICIO/INDEX
if st.session_state.submenu == "DataAnalyzer":
    st.markdown(
    "<h1 style='text-align: center;'>Data Analyzer</h1>",
    unsafe_allow_html=True
    )

    st.markdown(
    """
    <marquee behavior="scroll" direction="left" style="color:white; font-size:20px;">
        🌍 Descubre y compara el mundo de Airbnb en México, Albany, Valencia y Bangkok  
    </marquee>
    """,
    unsafe_allow_html=True
    )

    #st.divider()
    st.markdown("<br>", unsafe_allow_html=True)

    #MOSTRAMOS LAS BANDERAS DE CADA PAÍS
    col1, col2, col3, col4 = st.columns(4) 
    with col1:
        st.markdown(
            """
            <div style="background-color: rgba(0, 0, 0, 0.5); text-align: center; width: 100%; height: 115px; border-radius: 15px;">
                <p style="font-size: 16px; color: #a6acad; margin-top: 8px; font-weight: bold;">MÉXICO, MÉXICO</p>
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Flag_of_Mexico.svg/1280px-Flag_of_Mexico.svg.png" 
                    style="width: 130px; height: 60px; object-fit: cover; border-radius: 15px; box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);">
            </div>
            """,
            unsafe_allow_html=True
        )
    with col2:
        st.markdown(
            """
            <div style="background-color: rgba(0, 0, 0, 0.5); text-align: center; width: 100%; height: 115px; border-radius: 15px;">
                <p style="font-size: 16px; color: #a6acad; margin-top: 8px; font-weight: bold;">ALBANY, NY, USA</p>
                <img src="https://upload.wikimedia.org/wikipedia/commons/8/8d/Flag_of_Albany%2C_New_York.svg" 
                    style="width: 130px; height: 60px; object-fit: cover; border-radius: 15px; box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);">
                
            </div>
            """,
            unsafe_allow_html=True
        )
    with col3:
        st.markdown(
            """
            <div style="background-color: rgba(0, 0, 0, 0.5); text-align: center; width: 100%; height: 115px; border-radius: 15px;">
                <p style="font-size: 16px; color: #a6acad; margin-top: 8px; font-weight: bold;">VALENCIA, ESPAÑA</p>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHDltCMJWOwD_TXM0lBRmdTQM0RO9Ol97DFQ&s" 
                    style="width: 130px; height: 60px; object-fit: cover; border-radius: 15px; box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);">
                
            </div>
            """,
            unsafe_allow_html=True
        )
    with col4:
        st.markdown(
            """
            <div style="background-color: rgba(0, 0, 0, 0.5); text-align: center; width: 100%; height: 115px; border-radius: 15px;">
                <p style="font-size: 16px; color: #a6acad; margin-top: 8px; font-weight: bold;">BANGKOK, TAILANDIA</p>
                <img src="https://i.ytimg.com/vi/3VdXKJX8-3s/maxresdefault.jpg" 
                    style="width: 130px; height: 60px; object-fit: cover; border-radius: 15px; box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);">
                
            </div>
            """,
            unsafe_allow_html=True
        )


    st.divider()
    #st.markdown("<br>", unsafe_allow_html=True)
    
    #MOSTRAMOS LOS TÍTULOS DE CADA GRÁFICA
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Distribución de población por país")
    with col2:
        st.subheader("Proporción de registros por país")
    
    #MOSTRAMOS LA POBLACIÓN
    col1, col2, col3, col4 = st.columns([1, 3, 3, 1])
    with col1:
        st.markdown("""
            <div style='background-color: rgba(0, 0, 0, 0.5); padding: 5px; border-radius: 10px; text-align: center;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 100%; height: 105px; margin:5px;'>
                <p style='margin: 0; color: #6c757d; text: 15px; font-weight: bold;'>Población</p>
                <p style='margin: 2px 0; color: white; text-size: 10px; font-weight: bold;'>9,209,944</p>
                <p style='margin: 2px 0; color: white; text-size: 15px;'>MÉXICO</p>
            </div>
        """, unsafe_allow_html=True)

        st.markdown("""
            <div style='background-color: rgba(0, 0, 0, 0.5); padding: 5px; border-radius: 10px; text-align: center;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 100%; height: 105px; margin:5px;'>
                <p style='margin: 0; color: #6c757d; text: 15px; font-weight: bold;'>Población</p>
                <p style='margin: 2px 0; color: white; text-size: 10px; font-weight: bold;'>101, 228</p>
                <p style='margin: 2px 0; color: white; text-size: 15px;'>ALBANY</p>
            </div>
        """, unsafe_allow_html=True)

        st.markdown("""
            <div style='background-color: rgba(0, 0, 0, 0.5); padding: 5px; border-radius: 10px; text-align: center;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 100%; height: 105px; margin:5px;'>
                <p style='margin: 0; color: #6c757d; text: 15px; font-weight: bold;'>Población</p>
                <p style='margin: 2px 0; color: white; text-size: 10px; font-weight: bold;'>1, 615, 223</p>
                <p style='margin: 2px 0; color: white; text-size: 15px;'>VALENCIA</p>
            </div>
        """, unsafe_allow_html=True)

        st.markdown("""
            <div style='background-color: rgba(0, 0, 0, 0.5); padding: 5px; border-radius: 10px; text-align: center;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 100%; height: 105px; margin:5px;'>
                <p style='margin: 0; color: #6c757d; text: 15px; font-weight: bold;'>Población</p>
                <p style='margin: 2px 0; color: white; text-size: 10px; font-weight: bold;'>10, 539, 000</p>
                <p style='margin: 2px 0; color: white; text-size: 15px;'>BANGKOK</p>
            </div>
        """, unsafe_allow_html=True)
    with col2:
        # Datos de ejemplo
        data = {
            "País": ["México", "Albany", "Valencia", "Bangkok"],
            "Población": [9_209_944, 101_228, 1_615_223, 10_539_000]
        }
        dfG = pd.DataFrame(data)

        # Variables para eje X (categórica) y eje Y (numérica)
        Variable_cat = "País"
        Variable_num = "Población"

        # Crear gráfico
        fig = px.bar(
            data_frame=dfG,
            x=Variable_cat,
            y=Variable_num,
            text=Variable_num,  # Mostrar valores sobre las barras
            color=Variable_cat,  # Diferenciar con color
            color_discrete_map={
                "México": "#11711f",    # Verde
                "Albany": "#F3FF33",    # Amarillo
                "Valencia": "#0eadaf",  # Azul
                "Bangkok": "#cd0076"    # Rosa fuerte
            }
        )

        # Ajustes del gráfico
        fig.update_traces(texttemplate='%{text:,}', textposition='outside')
        fig.update_layout(
            xaxis_title="País",
            yaxis_title="Población",
            uniformtext_minsize=8,
            uniformtext_mode='hide',
            yaxis=dict(tickformat=',')  # Separador de miles
        )

        # Mostrar en Streamlit
        st.plotly_chart(fig)

    with col3:
        # Supongamos que ya tienes estos conteos:
        conteos = {
            "México": len(dfM),
            "Albany": len(dfA),
            "Valencia": len(dfV),
            "Bangkok": len(dfB)
        }

        # Crear DataFrame
        dfGG = pd.DataFrame(list(conteos.items()), columns=["País", "Registros"])

        # Gráfico de pastel
        fig = px.pie(
            dfGG,
            names="País",
            values="Registros",
            color="País",
            color_discrete_map={
                "México": "#11711f",    # Verde
                "Albany": "#F3FF33",    # Amarillo
                "Valencia": "#0eadaf",  # Azul
                "Bangkok": "#cd0076"    # Rosa fuerte
            }
        )

        fig.update_traces(textinfo="label+percent+value")

        # Mostrar en Streamlit
        st.plotly_chart(fig)

    with col4:
        st.markdown("""
            <div style='background-color: rgba(0, 0, 0, 0.5); padding: 5px; border-radius: 10px; text-align: center;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 100%; margin:5px; height: 105px;'>
                <p style='margin: 0; color: #6c757d; text: 15px; font-weight: bold;'>Registros</p>
                <p style='margin: 2px 0; color: white; text-size: 10px; font-weight: bold;'>26, 582</p>
                <p style='margin: 2px 0; color: white; text-size: 15px;'>MÉXICO</p>
            </div>
        """, unsafe_allow_html=True)

        st.markdown("""
            <div style='background-color: rgba(0, 0, 0, 0.5); padding: 5px; border-radius: 10px; text-align: center;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 100%; height: 25%; margin:5px; height: 105px;'>
                <p style='margin: 0; color: #6c757d; text: 15px; font-weight: bold;'>Registros</p>
                <p style='margin: 2px 0; color: white; text-size: 10px; font-weight: bold;'>421</p>
                <p style='margin: 2px 0; color: white; text-size: 15px;'>ALBANY</p>
            </div>
        """, unsafe_allow_html=True)

        st.markdown("""
            <div style='background-color: rgba(0, 0, 0, 0.5); padding: 5px; border-radius: 10px; text-align: center;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 100%; height: 25%; margin:5px; height: 105px;'>
                <p style='margin: 0; color: #6c757d; text: 15px; font-weight: bold;'>Registros</p>
                <p style='margin: 2px 0; color: white; text-size: 10px; font-weight: bold;'>9, 447</p>
                <p style='margin: 2px 0; color: white; text-size: 15px;'>VALENCIA</p>
            </div>
        """, unsafe_allow_html=True)

        st.markdown("""
            <div style='background-color: rgba(0, 0, 0, 0.5); padding: 5px; border-radius: 10px; text-align: center;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 100%; height: auto; margin:5px; height: 105px;'>
                <p style='margin: 0; color: #6c757d; text: 15px; font-weight: bold;'>Registros</p>
                <p style='margin: 2px 0; color: white; text-size: 10px; font-weight: bold;'>25, 079</p>
                <p style='margin: 2px 0; color: white; text-size: 15px;'>BANGKOK</p>
            </div>
        """, unsafe_allow_html=True)
    st.divider()



    #MOSTRAMOS UN CARRUSEL
    st.markdown("## !!Sumérgete en cada país¡¡")

    import base64
    def get_base64_image(image_path):
        with open(image_path, "rb") as img_file:
            b64_encoded = base64.b64encode(img_file.read()).decode()
        return f"data:image/jpeg;base64,{b64_encoded}"

    image_urls = [
        get_base64_image("mexico2.jpg"),
        get_base64_image("albany2.jpg"),
        get_base64_image("valencia3.jpg"),
        get_base64_image("bangkok2.jpg")
    ]
    carousel_html = f"""
    <style>
    .carousel-container {{
        position: relative;
        width: 100%;
        max-width: 700px;
        margin: auto;
        overflow: hidden;
        border-radius: 12px;
        box-shadow: 0 0 20px pink;
    }}

    .carousel-slide {{
        display: block;
        height: 100%;
    }}

    .carousel-slide img {{
        display: none;
        width: 100%;
        border-radius: 12px;
    }}

    .carousel-slide img.active {{
        display: block;
    }}

    .carousel-button {{
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background-color: rgba(0, 0, 0, 0.5);
        border: none;
        color: white;
        font-size: 2rem;
        padding: 8px 16px;
        cursor: pointer;
        z-index: 1;
        border-radius: 50%;
    }}

    #prevBtn {{
        left: 10px;
    }}

    #nextBtn {{
        right: 10px;
    }}
    </style>

    <div class="carousel-container">
        <button class="carousel-button" id="prevBtn">&#10094;</button>
        <div class="carousel-slide" id="carousel">
            {''.join([f'<img src="{img}" class="{ "active" if i == 0 else "" }" />' for i, img in enumerate(image_urls)])}
        </div>
        <button class="carousel-button" id="nextBtn">&#10095;</button>
    </div>

    <script>
    let slideIndex = 0;
    const slides = document.querySelectorAll('#carousel img');
    const totalSlides = slides.length;
    const intervalTime = 3000;
    let autoSlide = setInterval(showNextSlide, intervalTime);

    function updateSlide() {{
        slides.forEach((img, i) => {{
            img.classList.remove('active');
            if (i === slideIndex) {{
                img.classList.add('active');
            }}
        }});
    }}

    function showNextSlide() {{
        slideIndex = (slideIndex + 1) % totalSlides;
        updateSlide();
    }}

    function showPrevSlide() {{
        slideIndex = (slideIndex - 1 + totalSlides) % totalSlides;
        updateSlide();
    }}

    document.getElementById('nextBtn').addEventListener('click', () => {{
        clearInterval(autoSlide);
        showNextSlide();
        autoSlide = setInterval(showNextSlide, intervalTime);
    }});

    document.getElementById('prevBtn').addEventListener('click', () => {{
        clearInterval(autoSlide);
        showPrevSlide();
        autoSlide = setInterval(showNextSlide, intervalTime);
    }});
    </script>
    """

    st.components.v1.html(carousel_html, height=450)



#BOTÓN DE PRECIOS
elif st.session_state.submenu == "Precios":

    import streamlit as st
    import pandas as pd
    import plotly.graph_objects as go
    # Calcular el precio mínimo y máximo de cada DataFrame
    min_prices = [
    dfM['price'].min(), dfA['price'].min(), dfV['price'].min(), dfB['price'].min()
    ]
    max_prices = [
    dfM['price'].max(), dfA['price'].max(), dfV['price'].max(), dfB['price'].max()
    ]

    # Crear la figura para la gráfica de barras
    fig = go.Figure()

    # Agregar las barras para precios mínimos y máximos
    fig.add_trace(go.Bar(
    x=['México', 'Albany', 'Valencia', 'Bangkok'],
    y=min_prices,
    name='Precio mínimo',
    marker=dict(color='blue')
    ))

    fig.add_trace(go.Bar(
    x=['México', 'Albany', 'Valencia', 'Bangkok'],
    y=max_prices,
    name='Precio máximo',
    marker=dict(color='orange')
    ))

    # Personalizar la gráfica
    fig.update_layout(
    title='Comparación de Precios Mínimos y Máximos',
    xaxis_title='DataFrames',
    yaxis_title='Precios',
    barmode='group',  # Para que las barras se agrupen
    template='plotly',
    )

    # Mostrar la gráfica en Streamlit
    st.header("Precios minimos y maximos de los cuatros países")
    st.plotly_chart(fig)

    # Añadir pestañas para mejor organización
    tab1, tab2, tab3, tab4 = st.tabs(["México", "Albany", "Valencia", "Bangkok"])


###MÉXICO *************** MÉXICO **************** MÉXICO
    with tab1:
        st.markdown(
        "<h2 style='text-align: center;'>Precios en MÉXICO</h2>",
        unsafe_allow_html=True
        )

        #MOSTRAMOS LA SELECCIÓN DE FILTROS
        col1, col2 = st.columns(2)
        with col1:
            neighborhoods = dfM['neighbourhood'].unique()
            selected_neigh_M = st.multiselect("Filtrar por vecindario", neighborhoods, default=neighborhoods[:1], key="1")
        with col2:
            room_types = dfM['room_type'].unique()
            selected_room_M = st.selectbox("Tipo de habitación", room_types)

        # Filtro
        filtered_df = dfM[dfM['neighbourhood'].isin(selected_neigh_M)]
        filtered_df = filtered_df[filtered_df['room_type'] == selected_room_M]

        # Verificar si el DataFrame tiene datos
        if not filtered_df.empty:
            # Crear columnas de métricas
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Total de registros", len(filtered_df))
            with col2:
                st.metric("Precio promedio", f"${filtered_df['price'].mean():.2f}")
            with col3:
                st.metric("Precio mínimo", f"${filtered_df['price'].min():.2f}")
            with col4:
                st.metric("Precio máximo", f"${filtered_df['price'].max():.2f}")

            # Obtener propiedad más cara y más barata
            max_price_property = filtered_df.loc[filtered_df['price'].idxmax()]
            min_price_property = filtered_df.loc[filtered_df['price'].idxmin()]

            #MOSTRAMOS LAS TABLAS
            col1, col2 = st.columns(2)
            with col1:
                st.write("Propiedad más cara:")
                st.write(max_price_property[['name', 'price']])
            with col2:
                st.write("Propiedad más barata:")
                st.write(min_price_property[['name', 'price']])
        else:
            st.warning("⚠️ SIN DATOS")

        #MOSTRAMOS EL HISTOGRAMA DE PRECIOS CON EL MAX, MIN Y PROMEDIO
        with st.expander("HISTOGRAMA DE PRECIOS MAX, MIN Y PROMEDIO"):
            import plotly.graph_objects as go
            import plotly.express as px
            # Histograma base
            fig = px.histogram(filtered_df, x='price', nbins=20, title='Histograma de precios', color_discrete_sequence=['#11711f'])
            # Líneas verticales: mínimo, máximo y promedio
            fig.add_vline(
                x=filtered_df['price'].min(),
                line_color='black',
                line_dash='dash',
                annotation_text=f'Mínimo: ${filtered_df["price"].min():.2f}',
                annotation_position="top left"
            )
            fig.add_vline(
                x=filtered_df['price'].max(),
                line_color='red',
                line_dash='dash',
                annotation_text=f'Máximo: ${filtered_df["price"].max():.2f}',
                annotation_position="top right"
            )
            fig.add_vline(
                x=filtered_df['price'].mean(),
                line_color='blue',
                line_dash='dot',
                annotation_text=f'Promedio: ${filtered_df["price"].mean():.2f}',
                annotation_position="top"
            )
            # Mostrar en Streamlit
            st.plotly_chart(fig, use_container_width=True)

        st.divider()
        #CHECKBOX PARA MOSTRAR LA TABLA DEL DATASET
        if st.sidebar.checkbox("Tabla de México"):
            with st.container():
                st.markdown(
                    """
                    <div style="background-color: rgba(0, 0, 0, 0.5); padding: 20px; border-radius: 15px; box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);">
                        <h2 style="color: #c9cece; text-align: center;">Dataset de MÉXICO</h2>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

                # Selección de columnas
                selected_columns_M = st.multiselect(
                    "Selecciona las columnas que deseas visualizar:",
                    dfM.columns.tolist(),  # Lista de todas las columnas
                    default=dfM.columns[:5],  # Mostrar por defecto las primeras 5 columnas
                    key="2"
                )
                # Mostrar solo las columnas seleccionadas
                if selected_columns_M:
                    st.dataframe(dfM[selected_columns_M])
                else:
                    st.warning("⚠️ Por favor selecciona al menos una columna para visualizar.")

                st.markdown("---")

###ALBANY *************** ALBANY **************** ALBANY
    with tab2:
        st.markdown(
        "<h2 style='text-align: center;'>Precios en ALBANY</h2>",
        unsafe_allow_html=True
        )

        col1, col2 = st.columns(2)
        with col1:
            neighborhoods = dfA['neighbourhood'].unique()
            selected_neigh_A = st.multiselect("Filtrar por vecindario", neighborhoods, default=neighborhoods[:1], key="3")
        with col2:
            room_types = dfA['room_type'].unique()
            selected_room_A = st.selectbox("Tipo de habitación", room_types)

        # Filtro
        filtered_df = dfA[dfA['neighbourhood'].isin(selected_neigh_A)]
        filtered_df = filtered_df[filtered_df['room_type'] == selected_room_A]

        # Verificar si el DataFrame tiene datos
        if not filtered_df.empty:
            # Crear columnas de métricas
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Total de registros", len(filtered_df))
            with col2:
                st.metric("Precio promedio", f"${filtered_df['price'].mean():.2f}")
            with col3:
                st.metric("Precio mínimo", f"${filtered_df['price'].min():.2f}")
            with col4:
                st.metric("Precio máximo", f"${filtered_df['price'].max():.2f}")

            # Obtener propiedad más cara y más barata
            max_price_property = filtered_df.loc[filtered_df['price'].idxmax()]
            min_price_property = filtered_df.loc[filtered_df['price'].idxmin()]

            col1, col2 = st.columns(2)
            with col1:
                st.write("Propiedad más cara:")
                st.write(max_price_property[['name', 'price']])
            with col2:
                st.write("Propiedad más barata:")
                st.write(min_price_property[['name', 'price']])
        else:
            st.warning("⚠️ SIN DATOS")



#MOSTRAMOS EL HISTOGRAMA DE PRECIOS CON EL MAX, MIN Y PROMEDIO
        with st.expander("HISTOGRAMA DE PRECIOS MAX, MIN Y PROMEDIO"):  
            import plotly.graph_objects as go
            import plotly.express as px
            # Histograma base
            fig = px.histogram(filtered_df, x='price', nbins=20, title='Histograma de precios', color_discrete_sequence=['#F3FF33'])
            # Líneas verticales: mínimo, máximo y promedio
            fig.add_vline(
                x=filtered_df['price'].min(),
                line_color='black',
                line_dash='dash',
                annotation_text=f'Mínimo: ${filtered_df["price"].min():.2f}',
                annotation_position="top left"
            )
            fig.add_vline(
                x=filtered_df['price'].max(),
                line_color='red',
                line_dash='dash',
                annotation_text=f'Máximo: ${filtered_df["price"].max():.2f}',
                annotation_position="top right"
            )
            fig.add_vline(
                x=filtered_df['price'].mean(),
                line_color='blue',
                line_dash='dot',
                annotation_text=f'Promedio: ${filtered_df["price"].mean():.2f}',
                annotation_position="top"
            )
            # Mostrar en Streamlit
            st.plotly_chart(fig, use_container_width=True)

        
        st.divider()
        #CHECKBOX PARA MOSTRAR LA TABLA
        if st.sidebar.checkbox("Tabla de Albany"):
            with st.container():
                st.markdown(
                    """
                    <div style="background-color: rgba(0, 0, 0, 0.5); padding: 20px; border-radius: 15px; box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);">
                        <h2 style="color: #c9cece; text-align: center;">Dataset de Albany</h2>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

                # Selección de columnas
                selected_columns_A = st.multiselect(
                    "Selecciona las columnas que deseas visualizar:",
                    dfA.columns.tolist(),  # Lista de todas las columnas
                    default=dfA.columns[:5],  # Mostrar por defecto las primeras 5 columnas
                    key="4"
                )
                # Mostrar solo las columnas seleccionadas
                if selected_columns_A:
                    st.dataframe(dfA[selected_columns_A])
                else:
                    st.warning("⚠️ Por favor selecciona al menos una columna para visualizar.")

                st.markdown("---")


###VALENCIA *************** VALENCIA **************** VALENCIA
    with tab3:
        st.markdown(
        "<h2 style='text-align: center;'>Precios en VALENCIA</h2>",
        unsafe_allow_html=True
        )

        col1, col2 = st.columns(2)
        with col1:
            neighborhoods = dfV['neighbourhood'].unique()
            selected_neigh_V = st.multiselect("Filtrar por vecindario", neighborhoods, default=neighborhoods[:1], key="5")
        with col2:
            room_types = dfV['room_type'].unique()
            selected_room_V = st.selectbox("Tipo de habitación", room_types)

        # Filtro
        filtered_df = dfV[dfV['neighbourhood'].isin(selected_neigh_V)]
        filtered_df = filtered_df[filtered_df['room_type'] == selected_room_V]

        # Verificar si el DataFrame tiene datos
        if not filtered_df.empty:
            # Crear columnas de métricas
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Total de registros", len(filtered_df))
            with col2:
                st.metric("Precio promedio", f"${filtered_df['price'].mean():.2f}")
            with col3:
                st.metric("Precio mínimo", f"${filtered_df['price'].min():.2f}")
            with col4:
                st.metric("Precio máximo", f"${filtered_df['price'].max():.2f}")

            # Obtener propiedad más cara y más barata
            max_price_property = filtered_df.loc[filtered_df['price'].idxmax()]
            min_price_property = filtered_df.loc[filtered_df['price'].idxmin()]

            col1, col2 = st.columns(2)
            with col1:
                st.write("Propiedad más cara:")
                st.write(max_price_property[['name', 'price']])
            with col2:
                st.write("Propiedad más barata:")
                st.write(min_price_property[['name', 'price']])
        else:
            st.warning("⚠️ SIN DATOS")




#MOSTRAMOS EL HISTOGRAMA DE PRECIOS CON EL MAX, MIN Y PROMEDIO
        with st.expander("HISTOGRAMA DE PRECIOS MAX, MIN Y PROMEDIO"): 
            import plotly.graph_objects as go
            import plotly.express as px
            # Histograma base
            fig = px.histogram(filtered_df, x='price', nbins=20, title='Histograma de precios', color_discrete_sequence=['#0eadaf'])
            # Líneas verticales: mínimo, máximo y promedio
            fig.add_vline(
                x=filtered_df['price'].min(),
                line_color='black',
                line_dash='dash',
                annotation_text=f'Mínimo: ${filtered_df["price"].min():.2f}',
                annotation_position="top left"
            )
            fig.add_vline(
                x=filtered_df['price'].max(),
                line_color='red',
                line_dash='dash',
                annotation_text=f'Máximo: ${filtered_df["price"].max():.2f}',
                annotation_position="top right"
            )
            fig.add_vline(
                x=filtered_df['price'].mean(),
                line_color='blue',
                line_dash='dot',
                annotation_text=f'Promedio: ${filtered_df["price"].mean():.2f}',
                annotation_position="top"
            )
            # Mostrar en Streamlit
            st.plotly_chart(fig, use_container_width=True)

        st.divider()


        #CHECKBOX PARA MOSTRAR LA TABLA
        if st.sidebar.checkbox("Tabla de Valencia"):
            with st.container():
                st.markdown(
                    """
                    <div style="background-color: rgba(0, 0, 0, 0.5); padding: 20px; border-radius: 15px; box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);">
                        <h2 style="color: #c9cece; text-align: center;">Dataset de Valencia</h2>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

                # Selección de columnas
                selected_columns_V = st.multiselect(
                    "Selecciona las columnas que deseas visualizar:",
                    dfV.columns.tolist(),  # Lista de todas las columnas
                    default=dfV.columns[:5],  # Mostrar por defecto las primeras 5 columnas
                    key="6"
                )
                # Mostrar solo las columnas seleccionadas
                if selected_columns_V:
                    st.dataframe(dfV[selected_columns_V])
                else:
                    st.warning("⚠️ Por favor selecciona al menos una columna para visualizar.")

                st.markdown("---")

### BANGKOK *************** BANGKOK **************** BANGKOK
    with tab4:
        st.markdown(
            "<h2 style='text-align: center;'>Precios en BANGKOK</h2>",
            unsafe_allow_html=True
        )

        col1_B, col2_B = st.columns(2)
        with col1_B:
            neighborhoods_B = dfB['neighbourhood'].unique()
            selected_neigh_B = st.multiselect("Filtrar por vecindario", neighborhoods_B, default=neighborhoods_B[:1], key="vecindario_B")
        with col2_B:
            room_types_B = dfB['room_type'].unique()
            selected_room_B = st.selectbox("Tipo de habitación", room_types_B, key="tipo_habitacion_B")

        # Filtro
        filtered_df_B = dfB[dfB['neighbourhood'].isin(selected_neigh_B)]
        filtered_df_B = filtered_df_B[filtered_df_B['room_type'] == selected_room_B]

        # Verificar si el DataFrame tiene datos
        if not filtered_df_B.empty:
            # Crear columnas de métricas
            col1_B, col2_B, col3_B, col4_B = st.columns(4)
            with col1_B:
                st.metric("Total de registros", len(filtered_df_B))
            with col2_B:
                st.metric("Precio promedio", f"${filtered_df_B['price'].mean():.2f}")
            with col3_B:
                st.metric("Precio mínimo", f"${filtered_df_B['price'].min():.2f}")
            with col4_B:
                st.metric("Precio máximo", f"${filtered_df_B['price'].max():.2f}")

            # Obtener propiedad más cara y más barata
            max_price_property_B = filtered_df_B.loc[filtered_df_B['price'].idxmax()]
            min_price_property_B = filtered_df_B.loc[filtered_df_B['price'].idxmin()]

            col1_B, col2_B = st.columns(2)
            with col1_B:
                st.write("Propiedad más cara:")
                st.write(max_price_property_B[['name', 'price']])
            with col2_B:
                st.write("Propiedad más barata:")
                st.write(min_price_property_B[['name', 'price']])
        else:
            st.warning("⚠️ SIN DATOS")

        with st.expander("HISTOGRAMA DE PRECIOS MAX, MIN Y PROMEDIO"): 
            import plotly.graph_objects as go
            import plotly.express as px
            import ast  # Importar ast para seguridad en la conversión

            # MOSTRAMOS EL HISTOGRAMA DE PRECIOS CON EL MAX, MIN Y PROMEDIO
            fig = px.histogram(filtered_df_B, x='price', nbins=20, title='Histograma de precios', color_discrete_sequence=['#cd0076'])
            # Líneas verticales: mínimo, máximo y promedio
            fig.add_vline(
                x=filtered_df_B['price'].min(),
                line_color='green',
                line_dash='dash',
                annotation_text=f'Mínimo: ${filtered_df_B["price"].min():.2f}',
                annotation_position="top left"
            )
            fig.add_vline(
                x=filtered_df_B['price'].max(),
                line_color='red',
                line_dash='dash',
                annotation_text=f'Máximo: ${filtered_df_B["price"].max():.2f}',
                annotation_position="top right"
            )
            fig.add_vline(
                x=filtered_df_B['price'].mean(),
                line_color='blue',
                line_dash='dot',
                annotation_text=f'Promedio: ${filtered_df_B["price"].mean():.2f}',
                annotation_position="top"
            )
            # Mostrar en Streamlit
            st.plotly_chart(fig, use_container_width=True)

        st.divider()



        # CHECKBOX PARA MOSTRAR LA TABLA
        if st.sidebar.checkbox("Tabla de Bangkok"):
            with st.container():
                st.markdown(
                    """
                    <div style="background-color: rgba(0, 0, 0, 0.5); padding: 20px; border-radius: 15px; box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);">
                        <h2 style="color: #c9cece; text-align: center;">Dataset de Bangkok</h2>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

                # Selección de columnas
                selected_columns_B = st.multiselect(
                    "Selecciona las columnas que deseas visualizar:",
                    dfB.columns.tolist(),
                    default=dfB.columns[:5],
                    key="columnas_B"
                )
                if selected_columns_B:
                    st.dataframe(dfB[selected_columns_B])
                else:
                    st.warning("⚠️ Por favor selecciona al menos una columna para visualizar.")

                st.markdown("---")



# BOTÓN DE ANÁLISIS NÚMERICO Y CATEGÓRICO
elif st.session_state.submenu == "Análisis Númerico y Categórico":

    st.title("Análisis Númerico y Categórico")

    # Añadir pestañas para mejor organización
    st.sidebar.write("------------------------------")
    vista = st.sidebar.selectbox("Tipo de análisis", ["Categórico", "Numérico"])
    

    if vista == "Categórico":
        st.write("#### Distribución Categórica por Ciudad")

        city_options = {
            "México": dfM,
            "Albany": dfA,
            "Valencia": dfV,
            "Bangkok": dfB
        }
        st.sidebar.write("------------------------------")

        selected_cat_col = st.sidebar.selectbox("Variable categórica", text_cols, key=f"X1")
        n_top = st.sidebar.slider("Mostrar top categorías", 3, 15, 5)
        st.sidebar.write("Mostrar Gráfico de:")
        # Colores por ciudad
        pie_colors = {
            "México": ["#004d00", "#006600", "#009900", "#00cc00", "#00e600", "#1aff1a"],  # Tonos verdes
            "Albany": ["#FFD700", "#FFEA00", "#FFF700", "#FFFF33", "#FFFF66", "#FFFF99"],  # Amarillos
            "Valencia": ["#004080", "#0059b3", "#0073e6", "#3399ff", "#66b3ff", "#99ccff"],  # Azules
            "Bangkok": ["#800040", "#b30059", "#cc0073", "#e6008c", "#ff1aa3", "#ff4db8"]   # Rosas/Fucsias
        }

        bar_scales = {
            "México": "greens",
            "Albany": "YlOrBr",     # Amarillos-naranja
            "Valencia": "blues",
            "Bangkok": "pinkyl"     # Rosa claro
        }

        table_cmaps = {
            "México": "Greens",
            "Albany": "YlOrBr",
            "Valencia": "Blues",
            "Bangkok": "PuRd"
        }

        for city, city_df in city_options.items():
            if st.sidebar.checkbox(f"{city}", key=f"{city}_cat", value=(city == "México")):
                st.subheader(f"{city}")
                if selected_cat_col in city_df.columns:
                    freq_table = city_df[selected_cat_col].value_counts().reset_index()
                    freq_table.columns = [selected_cat_col, "Frecuencia"]
                    total = freq_table["Frecuencia"].sum()
                    freq_table["Porcentaje"] = (freq_table["Frecuencia"] / total * 100).round(2)
                    freq_table_top = freq_table.sort_values(by="Frecuencia", ascending=False).head(n_top)

                    col1, col2 = st.columns(2)
                    with col1:
                        fig_pie = px.pie(
                            freq_table_top, 
                            names=selected_cat_col, 
                            values="Frecuencia", 
                            title=f"{city}: Distribución de {selected_cat_col}", 
                            color_discrete_sequence=pie_colors[city]
                        )
                        fig_pie.update_traces(textposition='inside', textinfo='percent+label')
                        st.plotly_chart(fig_pie, use_container_width=True)

                    with col2:
                        fig_bar = px.bar(
                            freq_table_top, 
                            x=selected_cat_col, 
                            y="Frecuencia",
                            color="Frecuencia",
                            color_continuous_scale=bar_scales[city],  # <- Aquí cambia según ciudad
                            title=f"{city}: Frecuencia de {selected_cat_col}"
                        )
                        st.plotly_chart(fig_bar, use_container_width=True)

                    if st.checkbox(f"Mostrar tabla de frecuencias para {city}", key=f"{city}_tabla"):
                        st.dataframe(freq_table.style.background_gradient(cmap=table_cmaps[city], subset=["Frecuencia"]))

   

    elif vista == "Numérico":
        city_color_map = {
            "México": "#11711f",     # Verde
            "Albany": "#F3FF33",     # Amarillo
            "Valencia": "#0eadaf",   # Azul
            "Bangkok": "#cd0076"     # Rosa fuerte
        }

        city_color_palettes = {
            "México": "Greens",
            "Albany": "YlOrBr",
            "Valencia": "Blues",
            "Bangkok": "PuRd"
        }
        city_discrete_palettes = {
            "México": ["#004d00", "#006600", "#009900", "#00cc00", "#00e600", "#1aff1a"],
            "Albany": ["#ffffcc", "#ffeda0", "#fed976", "#feb24c", "#fd8d3c", "#fc4e2a"],
            "Valencia": ["#08306b", "#08519c", "#2171b5", "#4292c6", "#6baed6", "#9ecae1"],
            "Bangkok": ["#67001f", "#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#f7f7f7"]
        }


        st.write("#### Distribución Numérica por Ciudad")
        city_options = {
            "México": dfM,
            "Albany": dfA,
            "Valencia": dfV,
            "Bangkok": dfB
        }
        st.sidebar.write("------------------------------")

        numerics_vars_selected = st.sidebar.multiselect(
            label="Variables numéricas a graficar", options=numeric_cols,
            default=["accommodates", "beds"], key="numerics_vars_selected"
        )
        category_selected = st.sidebar.selectbox("Filtrar por tipo de habitación", options=unique_categories_room)
        plot_type = st.sidebar.radio("Tipo de gráfico", ["Line Plot", "Scatter Plot"])

        if plot_type == "Scatter Plot":
            show_trend = st.sidebar.checkbox("Mostrar línea de tendencia", value=True)
        else:
            show_trend = False

        st.sidebar.write("Mostrar Gráfico de:")
        for city, city_df in city_options.items():
            if st.sidebar.checkbox(f"{city}", value=(city == "México"), key=f"{city}_num"):
                st.subheader(f"{city}")
                data = city_df[city_df['room_type'] == category_selected]

                if numerics_vars_selected:
                    data_features = data[numerics_vars_selected]

                    if plot_type == "Line Plot":
                        fig_line = px.line(
                            data_frame=data_features,
                            x=data_features.index,
                            y=numerics_vars_selected,
                            title=f"{city}: Variables numéricas para {category_selected}",
                            height=500,
                            color_discrete_sequence=city_discrete_palettes[city] # Color único por ciudad
                        )
                        fig_line.update_layout(hovermode="x unified")
                        st.plotly_chart(fig_line, use_container_width=True)

                    elif plot_type == "Scatter Plot" and len(numerics_vars_selected) >= 2:
                        fig_scatter = px.scatter(
                            data_frame=data_features,
                            x=numerics_vars_selected[0],
                            y=numerics_vars_selected[1],
                            title=f"{city}: Relación entre {numerics_vars_selected[0]} y {numerics_vars_selected[1]}",
                            opacity=0.7,
                            color=data_features[numerics_vars_selected[1]],  # Color por valor Y
                            color_continuous_scale=city_color_palettes[city],
                            trendline="ols" if show_trend else None
                        )
                        st.plotly_chart(fig_scatter, use_container_width=True)
                else:
                    st.info(f"Selecciona variables numéricas para mostrar datos de {city}.")

# BOTÓN DE REGRESIÓN
elif st.session_state.submenu == "Regresión":
    st.title("Análisis de Regresión")
    #mostrar_matriz = st.sidebar.checkbox("Mostrar heatmap", value=True)

    with st.expander("Mostrar matrices de correlación"):
        ########################################################################3
        st.subheader("Matriz de Correlación: México")
        if 'numeric_df_M' in locals() and not numeric_df_M.empty and numeric_df_M.shape[1] >= 2:
            corr = numeric_df_M.corr()
            Corr_Factors = abs(corr)
            fig = px.imshow(
                Corr_Factors,
                color_continuous_scale=px.colors.sequential.Greens,
                text_auto='.2f',
                aspect='equal',
                labels=dict(color="Correlación")
            )
            fig.update_layout(
                title='Matriz de Correlación: México',
                title_font=dict(size=22),
                width=800,
                height=600,
                xaxis_title='',
                yaxis_title='',
                xaxis={'side': 'bottom'},
                margin=dict(l=50, r=50, t=80, b=50),
            )
            fig.update_traces(
                textfont=dict(size=12, color='black', family='Arial Bold'),
                hoverinfo='all',
                hovertemplate='x: %{x}<br>y: %{y}<br>Correlación: %{z:.4f}<extra></extra>'
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No hay suficientes datos numéricos en México para calcular correlaciones.")
        ############################################################################
        st.subheader("Matriz de Correlación: Albany")
        if 'numeric_df_A' in locals() and not numeric_df_A.empty and numeric_df_A.shape[1] >= 2:
            corr = numeric_df_A.corr()
            Corr_Factors = abs(corr)
            fig = px.imshow(
                Corr_Factors,
                color_continuous_scale=px.colors.sequential.Oranges,
                text_auto='.2f',
                aspect='equal',
                labels=dict(color="Correlación")
            )
            fig.update_layout(
                title='Matriz de Correlación: Albany',
                title_font=dict(size=22),
                width=800,
                height=600,
                xaxis_title='',
                yaxis_title='',
                xaxis={'side': 'bottom'},
                margin=dict(l=50, r=50, t=80, b=50),
            )
            fig.update_traces(
                textfont=dict(size=12, color='black', family='Arial Bold'),
                hoverinfo='all',
                hovertemplate='x: %{x}<br>y: %{y}<br>Correlación: %{z:.4f}<extra></extra>'
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No hay suficientes datos numéricos en Albany para calcular correlaciones.")
        ##########################################################################
        st.subheader("Matriz de Correlación: Valencia")
        if 'numeric_df_V' in locals() and not numeric_df_V.empty and numeric_df_V.shape[1] >= 2:
            corr = numeric_df_V.corr()
            Corr_Factors = abs(corr)
            fig = px.imshow(
                Corr_Factors,
                color_continuous_scale=px.colors.sequential.Blues,
                text_auto='.2f',
                aspect='equal',
                labels=dict(color="Correlación")
            )
            fig.update_layout(
                title='Matriz de Correlación: Valencia',
                title_font=dict(size=22),
                width=800,
                height=600,
                xaxis_title='',
                yaxis_title='',
                xaxis={'side': 'bottom'},
                margin=dict(l=50, r=50, t=80, b=50),
            )
            fig.update_traces(
                textfont=dict(size=12, color='black', family='Arial Bold'),
                hoverinfo='all',
                hovertemplate='x: %{x}<br>y: %{y}<br>Correlación: %{z:.4f}<extra></extra>'
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No hay suficientes datos numéricos en Valencia para calcular correlaciones.")

        ##########################################################################
        st.subheader("Matriz de Correlación: Bangkok")

        if 'numeric_df_B' in locals() and not numeric_df_B.empty and numeric_df_B.shape[1] >= 2:
            corr = numeric_df_B.corr()
            Corr_Factors = abs(corr)
            fig = px.imshow(
                Corr_Factors,
                color_continuous_scale=px.colors.sequential.RdPu,
                text_auto='.2f',
                aspect='equal',
                labels=dict(color="Correlación")
            )
            fig.update_layout(
                title='Matriz de Correlación: Bangkok',
                title_font=dict(size=22),
                width=800,
                height=600,
                xaxis_title='',
                yaxis_title='',
                xaxis={'side': 'bottom'},
                margin=dict(l=50, r=50, t=80, b=50),
            )
            fig.update_traces(
                textfont=dict(size=12, color='black', family='Arial Bold'),
                hoverinfo='all',
                hovertemplate='x: %{x}<br>y: %{y}<br>Correlación: %{z:.4f}<extra></extra>'
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No hay suficientes datos numéricos en Bangkok para calcular correlaciones.")

    # Añadir pestañas para mejor organización
    st.sidebar.write("------------------------------")
    vista = st.sidebar.selectbox("Tipo de análisis", ["Lineal Simple", "Lineal Múltiple", "Logística"])
    st.sidebar.write("------------------------------")
#######################****LINEAL SIMPLE*******************************************
    if vista == "Lineal Simple":
        st.write("#### Regresión lineal simple")
        col_x_global = st.sidebar.selectbox("Variable Independiente (X)", list(set(numeric_cols_M) & set(numeric_cols_A) & set(numeric_cols_V) & set(numeric_cols_B)), key="global_rls_x", index=0)
        col_y_global = st.sidebar.selectbox("Variable Dependiente (Y)", list(set(numeric_cols_M) & set(numeric_cols_A) & set(numeric_cols_V) & set(numeric_cols_B)), key="global_rls_y", index=2)

        vistaLineal = st.sidebar.multiselect("País", ["México", "Albany", "Valencia", "Bangkok"], default=["México", "Albany", "Valencia", "Bangkok"], key="vistaLineal")
        col1, col2 = st.columns(2)
        with col1:
            if "México" in vistaLineal:
                st.subheader("México")

                X_M = dfM[[col_x_global]].values.reshape(-1, 1)
                y_M = dfM[col_y_global].values.reshape(-1, 1)

                model_M = LinearRegression()
                model_M.fit(X_M, y_M)
                y_pred_M = model_M.predict(X_M)

                st.write(f"**Coeficiente (México):** {model_M.coef_[0][0]:.4f}")
                st.write(f"**Intercepto (México):** {model_M.intercept_[0]:.4f}")

                scatter_M = px.scatter(dfM, x=col_x_global, y=col_y_global, color_discrete_sequence=['green'])
                scatter_M.add_scatter(x=dfM[col_x_global], y=y_pred_M.flatten(), mode='lines', name='Línea de Regresión',
                                    line=dict(color='red', width=3))
                #     # Luego agregamos los puntos
                # scatter_M.add_scatter(x=dfM[col_x_global], y=dfM[col_y_global], mode='markers', ,
                #                     marker=dict(color='pink', size=6, opacity=0.7))
                st.plotly_chart(scatter_M, use_container_width=True)
        with col2:
            if "Albany" in vistaLineal:
                st.subheader("Albany")

                X_A = dfA[[col_x_global]].values.reshape(-1, 1)
                y_A = dfA[col_y_global].values.reshape(-1, 1)

                model_A = LinearRegression()
                model_A.fit(X_A, y_A)
                y_pred_A = model_A.predict(X_A)

                st.write(f"**Coeficiente (Albany):** {model_A.coef_[0][0]:.4f}")
                st.write(f"**Intercepto (Albany):** {model_A.intercept_[0]:.4f}")

                scatter_A = px.scatter(dfA, x=col_x_global, y=col_y_global, color_discrete_sequence=['#F3FF33'])
                scatter_A.add_scatter(x=dfA[col_x_global], y=y_pred_A.flatten(), mode='lines', name='Línea de Regresión',
                                    line=dict(color='red', width=3))
                st.plotly_chart(scatter_A, use_container_width=True)


        col1, col2 = st.columns(2)
        with col1:
            if "Valencia" in vistaLineal:
                st.subheader("Valencia")

                X_V = dfV[[col_x_global]].values.reshape(-1, 1)
                y_V = dfV[col_y_global].values.reshape(-1, 1)

                model_V = LinearRegression()
                model_V.fit(X_V, y_V)
                y_pred_V = model_V.predict(X_V)

                st.write(f"**Coeficiente (Valencia):** {model_V.coef_[0][0]:.4f}")
                st.write(f"**Intercepto (Valencia):** {model_V.intercept_[0]:.4f}")

                scatter_V = px.scatter(dfV, x=col_x_global, y=col_y_global, color_discrete_sequence=['#0eadaf'])
                scatter_V.add_scatter(x=dfV[col_x_global], y=y_pred_V.flatten(), mode='lines', name='Línea de Regresión',
                                        line=dict(color='red', width=3))
                st.plotly_chart(scatter_V, use_container_width=True)
        with col2:
            if "Bangkok" in vistaLineal:
                st.subheader("Bangkok")

                X_B = dfB[[col_x_global]].values.reshape(-1, 1)
                y_B = dfB[col_y_global].values.reshape(-1, 1)

                model_B = LinearRegression()
                model_B.fit(X_B, y_B)
                y_pred_B = model_B.predict(X_B)

                st.write(f"**Coeficiente (Bangkok):** {model_B.coef_[0][0]:.4f}")
                st.write(f"**Intercepto (Bangkok):** {model_B.intercept_[0]:.4f}")

                scatter_B = px.scatter(dfB, x=col_x_global, y=col_y_global, color_discrete_sequence=['#cd0076'])
                scatter_B.add_scatter(x=dfB[col_x_global], y=y_pred_B.flatten(), mode='lines', name='Línea de Regresión',
                                    line=dict(color='red', width=3))
                st.plotly_chart(scatter_B, use_container_width=True)

    elif vista == "Lineal Múltiple":
        col_x_global = st.sidebar.multiselect("Variable Independiente (X)", list(set(numeric_cols_M) & set(numeric_cols_A) & set(numeric_cols_V) & set(numeric_cols_B)), key="global_rls_x_x", default=[list(set(numeric_cols_M) & set(numeric_cols_A) & set(numeric_cols_V) & set(numeric_cols_B))[0], list(set(numeric_cols_M) & set(numeric_cols_A) & set(numeric_cols_V) & set(numeric_cols_B))[2]])
        col_y_global = st.sidebar.selectbox("Variable Dependiente (Y)", list(set(numeric_cols_M) & set(numeric_cols_A) & set(numeric_cols_V) & set(numeric_cols_B)), key="global_rls_y_y", index=1)

        vistaLineal = st.sidebar.multiselect("País", ["México", "Albany", "Valencia", "Bangkok"], default=["México", "Albany", "Valencia", "Bangkok"], key="vistaLineal")
        col1, col2 = st.columns(2)
        with col1:
            st.subheader("México")
            if col_x_global and col_y_global:
                X_mult_M = dfM[col_x_global]
                y_mult_M = dfM[col_y_global]

                model_mult_M = LinearRegression()
                model_mult_M.fit(X_mult_M, y_mult_M)
                y_pred_mult_M = model_mult_M.predict(X_mult_M)

                st.write("**Coeficientes:**")
                coef_df_M = pd.DataFrame({
                    'Variable': col_x_global,
                    'Coeficiente': model_mult_M.coef_
                })
                st.dataframe(coef_df_M)

                st.write(f"**Intercepto:** {model_mult_M.intercept_:.4f}")

                # Gráfico de valores reales vs predichos
                fig, ax = plt.subplots(figsize=(8, 6))
                ax.scatter(range(len(y_mult_M)), y_mult_M, color='gray', alpha=0.6, label='Reales')
                ax.scatter(range(len(y_pred_mult_M)), y_pred_mult_M, color='green', label='Predichos')

                # Líneas que conectan real con predicho
                np.random.seed(42)
                indices = np.random.choice(range(len(y_mult_M)), 10, replace=False)
                for i in indices:
                    ax.plot([i, i], [y_mult_M.iloc[i], y_pred_mult_M[i]], color='red', alpha=0.5)

                ax.set_title('Regresión Lineal Múltiple: Reales vs Predichos (México)')
                ax.set_xlabel('Índice de observación')
                ax.set_ylabel('Valor')
                ax.legend()
                st.pyplot(fig)

        with col2:
            st.subheader("Albany")
            if col_x_global and col_y_global:
                X_mult_A = dfA[col_x_global]
                y_mult_A = dfA[col_y_global]

                model_mult_A = LinearRegression()
                model_mult_A.fit(X_mult_A, y_mult_A)
                y_pred_mult_A = model_mult_A.predict(X_mult_A)

                st.write("**Coeficientes:**")
                coef_df_A = pd.DataFrame({
                    'Variable': col_x_global,
                    'Coeficiente': model_mult_A.coef_
                })
                st.dataframe(coef_df_A)

                st.write(f"**Intercepto:** {model_mult_A.intercept_:.4f}")

                # Gráfico de valores reales vs predichos
                fig, ax = plt.subplots(figsize=(8, 6))
                ax.scatter(range(len(y_mult_A)), y_mult_A, color='gray', alpha=0.6, label='Reales')
                ax.scatter(range(len(y_pred_mult_A)), y_pred_mult_A, color='#F3FF33', label='Predichos')

                # Líneas que conectan real con predicho
                np.random.seed(42)
                indices = np.random.choice(range(len(y_mult_A)), 10, replace=False)
                for i in indices:
                    ax.plot([i, i], [y_mult_A.iloc[i], y_pred_mult_A[i]], color='red', alpha=0.5)

                ax.set_title('Regresión Lineal Múltiple: Reales vs Predichos (Albany)')
                ax.set_xlabel('Índice de observación')
                ax.set_ylabel('Valor')
                ax.legend()
                st.pyplot(fig)

        col1, col2 = st.columns(2)
        with col1:
            st.subheader("Valencia")
            if col_x_global and col_y_global:
                X_mult_V = dfV[col_x_global]
                y_mult_V = dfV[col_y_global]

                model_mult_V = LinearRegression()
                model_mult_V.fit(X_mult_V, y_mult_V)
                y_pred_mult_V = model_mult_V.predict(X_mult_V)

                st.write("**Coeficientes:**")
                coef_df_V = pd.DataFrame({
                    'Variable': col_x_global,
                    'Coeficiente': model_mult_V.coef_
                })
                st.dataframe(coef_df_V)

                st.write(f"**Intercepto:** {model_mult_V.intercept_:.4f}")

                # Gráfico de valores reales vs predichos
                fig, ax = plt.subplots(figsize=(8, 6))
                ax.scatter(range(len(y_mult_V)), y_mult_V, color='gray', alpha=0.6, label='Reales')
                ax.scatter(range(len(y_pred_mult_V)), y_pred_mult_V, color='#0eadaf', label='Predichos')

                # Líneas que conectan real con predicho
                np.random.seed(42)
                indices = np.random.choice(range(len(y_mult_V)), 10, replace=False)
                for i in indices:
                    ax.plot([i, i], [y_mult_V.iloc[i], y_pred_mult_V[i]], color='red', alpha=0.5)

                ax.set_title('Regresión Lineal Múltiple: Reales vs Predichos (Valencia)')
                ax.set_xlabel('Índice de observación')
                ax.set_ylabel('Valor')
                ax.legend()
                st.pyplot(fig)

        with col2:

            st.subheader("Bangkok")

            if col_x_global and col_y_global:
                X_mult_B = dfB[col_x_global]
                y_mult_B = dfB[col_y_global]

                model_mult_B = LinearRegression()
                model_mult_B.fit(X_mult_B, y_mult_B)
                y_pred_mult_B = model_mult_B.predict(X_mult_B)

                st.write("**Coeficientes:**")
                coef_df_B = pd.DataFrame({
                    'Variable': col_x_global,
                    'Coeficiente': model_mult_B.coef_
                })
                st.dataframe(coef_df_B)

                st.write(f"**Intercepto:** {model_mult_B.intercept_:.4f}")

                # Gráfico de valores reales vs predichos
                fig, ax = plt.subplots(figsize=(8, 6))
                ax.scatter(range(len(y_mult_B)), y_mult_B, color='gray', alpha=0.6, label='Reales')
                ax.scatter(range(len(y_pred_mult_B)), y_pred_mult_B, color='#cd0076', label='Predichos')

                # Líneas que conectan real con predicho
                np.random.seed(42)
                indices = np.random.choice(range(len(y_mult_B)), 10, replace=False)
                for i in indices:
                    ax.plot([i, i], [y_mult_B.iloc[i], y_pred_mult_B[i]], color='red', alpha=0.5)

                ax.set_title('Regresión Lineal Múltiple: Reales vs Predichos (Bangkok)')
                ax.set_xlabel('Índice de observación')
                ax.set_ylabel('Valor')
                ax.legend()
                st.pyplot(fig)

    elif vista == "Logística":
        st.write("#### Regresión Logística")
        col_x_global = st.sidebar.multiselect("Variable Independiente (X)", list(set(numeric_cols_M) & set(numeric_cols_A) & set(numeric_cols_V) & set(numeric_cols_B)), key="global_rls_x_x", default=[list(set(numeric_cols_M) & set(numeric_cols_A) & set(numeric_cols_V) & set(numeric_cols_B))[0]])
        ############México
        st.subheader("México")
        binary_cols_M = [col for col in dfM.columns if dfM[col].nunique() == 2 and dfM[col].dtype == 'object']
        candidates_M = [col for col in dfM.columns if dfM[col].dtype == 'object' and 2 < dfM[col].nunique() <= 60]
        binarized_map_M = {}

        for col in candidates_M:
            valores = dfM[col].dropna().unique()
            if len(valores) >= 2:
                positivo, negativo = valores[0], valores[1]
                nueva_col = f"{col}_{positivo}_vs_{negativo}"
                dfM[nueva_col] = dfM[col].apply(lambda x: 1 if x == positivo else (0 if x == negativo else np.nan))
                dfM = dfM[dfM[nueva_col].isin([0, 1])]
                binary_cols_M.append(col)
                binarized_map_M[col] = nueva_col

        target_var_log_M = st.sidebar.selectbox("Variable Dependiente - México", sorted(set(binary_cols_M)), key="log_y_M")
        target_real_M = binarized_map_M.get(target_var_log_M, target_var_log_M)

        if col_x_global and target_var_log_M:
            df_log_M = dfM.dropna(subset=col_x_global + [target_real_M])
            X = df_log_M[col_x_global]
            y = df_log_M[target_real_M]
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.6)
            X_train = StandardScaler().fit_transform(X_train)
            X_test = StandardScaler().fit(X_train).transform(X_test)

            model = LogisticRegression(max_iter=200)
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)

            st.write(f"Precisión: {accuracy_score(y_test, y_pred)*100:.2f}%")
            st.dataframe(pd.DataFrame({'Variable': col_x_global, 'Coeficiente': model.coef_[0]}))
            matriz = confusion_matrix(y_test, y_pred)
            fig = ff.create_annotated_heatmap(z=matriz, annotation_text=matriz, colorscale='Greens', showscale=True)
            fig.update_layout(title='Matriz de Confusión - México')
            st.plotly_chart(fig)
            report = classification_report(y_test, y_pred, output_dict=True)
            st.dataframe(pd.DataFrame(report).transpose())

            ########ALBANY
            st.subheader("Albany")

            # Variables categóricas binarias
            binary_cols_A = [col for col in dfA.columns if dfA[col].nunique() == 2 and dfA[col].dtype == 'object']
            candidates_A = [col for col in dfA.columns if dfA[col].dtype == 'object' and 2 < dfA[col].nunique() <= 60]
            binarized_map_A = {}

            for col in candidates_A:
                valores = dfA[col].dropna().unique()
                if len(valores) >= 2:
                    positivo, negativo = valores[0], valores[1]
                    nueva_col = f"{col}_{positivo}_vs_{negativo}"
                    dfA[nueva_col] = dfA[col].apply(lambda x: 1 if x == positivo else (0 if x == negativo else np.nan))
                    dfA = dfA[dfA[nueva_col].isin([0, 1])]
                    binary_cols_A.append(col)
                    binarized_map_A[col] = nueva_col

            target_var_log_A = st.sidebar.selectbox("Variable Dependiente - Albany", sorted(set(binary_cols_A)), key="log_y_A")
            target_real_A = binarized_map_A.get(target_var_log_A, target_var_log_A)

            if col_x_global and target_var_log_A:
                df_log_A = dfA.dropna(subset=col_x_global + [target_real_A])
                X = df_log_A[col_x_global]
                y = df_log_A[target_real_A]

                X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.6)
                X_train = StandardScaler().fit_transform(X_train)
                X_test = StandardScaler().fit(X_train).transform(X_test)

                model = LogisticRegression(max_iter=200)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)

                st.write(f"Precisión: {accuracy_score(y_test, y_pred)*100:.2f}%")
                st.dataframe(pd.DataFrame({'Variable': col_x_global, 'Coeficiente': model.coef_[0]}))

                matriz = confusion_matrix(y_test, y_pred)
                fig = ff.create_annotated_heatmap(z=matriz, annotation_text=matriz, colorscale='Oranges', showscale=True)
                fig.update_layout(title='Matriz de Confusión - Albany')
                st.plotly_chart(fig)

                report = classification_report(y_test, y_pred, output_dict=True)
                st.dataframe(pd.DataFrame(report).transpose())

                ###############VALENCIA
                st.subheader("Valencia")
                binary_cols_V = [col for col in dfV.columns if dfV[col].nunique() == 2 and dfV[col].dtype == 'object']
                candidates_V = [col for col in dfV.columns if dfV[col].dtype == 'object' and 2 < dfV[col].nunique() <= 60]
                binarized_map_V = {}

                for col in candidates_V:
                    valores = dfV[col].dropna().unique()
                    if len(valores) >= 2:
                        positivo, negativo = valores[0], valores[1]
                        nueva_col = f"{col}_{positivo}_vs_{negativo}"
                        dfV[nueva_col] = dfV[col].apply(lambda x: 1 if x == positivo else (0 if x == negativo else np.nan))
                        dfV = dfV[dfV[nueva_col].isin([0, 1])]
                        binary_cols_V.append(col)
                        binarized_map_V[col] = nueva_col

                target_var_log_V = st.sidebar.selectbox("Variable Dependiente - Valencia", sorted(set(binary_cols_V)), key="log_y_V")
                target_real_V = binarized_map_V.get(target_var_log_V, target_var_log_V)

                if col_x_global and target_var_log_V:
                    df_log_V = dfV.dropna(subset=col_x_global + [target_real_V])
                    X = df_log_V[col_x_global]
                    y = df_log_V[target_real_V]
                    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.6)
                    X_train = StandardScaler().fit_transform(X_train)
                    X_test = StandardScaler().fit(X_train).transform(X_test)

                    model = LogisticRegression(max_iter=200)
                    model.fit(X_train, y_train)
                    y_pred = model.predict(X_test)

                    st.write(f"Precisión: {accuracy_score(y_test, y_pred)*100:.2f}%")
                    st.dataframe(pd.DataFrame({'Variable': col_x_global, 'Coeficiente': model.coef_[0]}))
                    matriz = confusion_matrix(y_test, y_pred)
                    fig = ff.create_annotated_heatmap(z=matriz, annotation_text=matriz, colorscale='Blues', showscale=True)
                    fig.update_layout(title='Matriz de Confusión - Valencia')
                    st.plotly_chart(fig)
                    report = classification_report(y_test, y_pred, output_dict=True)
                    st.dataframe(pd.DataFrame(report).transpose())

                    #######Bangkok
                    st.subheader("Bangkok")
                    binary_cols_B = [col for col in dfB.columns if dfB[col].nunique() == 2 and dfB[col].dtype == 'object']
                    candidates_B = [col for col in dfB.columns if dfB[col].dtype == 'object' and 2 < dfB[col].nunique() <= 60]
                    binarized_map_B = {}

                    for col in candidates_B:
                        valores = dfB[col].dropna().unique()
                        if len(valores) >= 2:
                            positivo, negativo = valores[0], valores[1]
                            nueva_col = f"{col}_{positivo}_vs_{negativo}"
                            dfB[nueva_col] = dfB[col].apply(lambda x: 1 if x == positivo else (0 if x == negativo else np.nan))
                            dfB = dfB[dfB[nueva_col].isin([0, 1])]
                            binary_cols_B.append(col)
                            binarized_map_B[col] = nueva_col

                    target_var_log_B = st.sidebar.selectbox("Variable Dependiente - Bangkok", sorted(set(binary_cols_B)), key="log_y_B")
                    target_real_B = binarized_map_B.get(target_var_log_B, target_var_log_B)

                    if col_x_global and target_var_log_B:
                        df_log_B = dfB.dropna(subset=col_x_global + [target_real_B])
                        X = df_log_B[col_x_global]
                        y = df_log_B[target_real_B]
                        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.6)
                        X_train = StandardScaler().fit_transform(X_train)
                        X_test = StandardScaler().fit(X_train).transform(X_test)

                        model = LogisticRegression(max_iter=200)
                        model.fit(X_train, y_train)
                        y_pred = model.predict(X_test)

                        st.write(f"Precisión: {accuracy_score(y_test, y_pred)*100:.2f}%")
                        st.dataframe(pd.DataFrame({'Variable': col_x_global, 'Coeficiente': model.coef_[0]}))
                        matriz = confusion_matrix(y_test, y_pred)
                        fig = ff.create_annotated_heatmap(z=matriz, annotation_text=matriz, colorscale='pinkyl', showscale=True)
                        fig.update_layout(title='Matriz de Confusión - Bangkok')
                        st.plotly_chart(fig)
                        report = classification_report(y_test, y_pred, output_dict=True)
                        st.dataframe(pd.DataFrame(report).transpose())









